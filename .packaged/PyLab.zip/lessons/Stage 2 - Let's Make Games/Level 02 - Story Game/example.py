# Story start
print()
print("You are walking in the forest and you see a house. You have been walking for a long time and are")
print("quite hungry and cold. Looking into the window, you see a nice warm fire and some warm food on the table.")
print()
print("What do you do?")
print()
print("1 - Knock on the door.")
print("2 - Try to open the door.")
print("3 - Try to sneak in through the window.")
print("4 - Leave the house and continue into the forest.")
print()

playerChoice = input("Enter choice: ")

if playerChoice == "1":
    print("Choice 1")


if playerChoice == "2":
    print("")


if playerChoice == "3":
    print("")

if playerChoice == "4":
    print("")
