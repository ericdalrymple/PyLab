# ================================================================================================== #
# EXERCISE:
#
#   Read the code in this file. Then run the program and answer the questions
#   to see if you can guess that VALUES saved in the VARIABLES.
#
# ================================================================================================== #

a = input("Type a value for A: ")
b = input("Type a value for B: ")
c = input("Type a value for C: ")

guess = input("Guess the value for A:")
print("You guessed:", guess)
print("The value is", a)
