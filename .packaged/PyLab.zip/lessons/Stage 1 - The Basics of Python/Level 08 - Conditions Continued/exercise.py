# ================================================================================================== #
# EXERCISE:
#
#   Two players are playing "Rock", "Paper", "Scissors".
#
#   - "Rock" wins against "Scissors"
#   - "Scissors" wins against "Papaer"
#   - "Paper" wins against "Rock"
#
#   This code asks the moves for both players. Your code should announce which
#   player is the winner!
#
# ================================================================================================== #

player1_move = input("Player 1 Move: ")
player2_move = input("Player 2 Move: ")

# Write your code below this line.
