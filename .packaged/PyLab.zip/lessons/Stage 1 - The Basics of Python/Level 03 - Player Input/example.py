# ================================================= #
# ======= LEVEL 3: Asking Player for Values ======= #
# ================================================= #

# Maybe these program aren't very fun yet. Let's spice things up by asking the player
# some questions! We can use the 'input' instruction to ask someone to enter a VALUE.

# Let's ask the player to write a message and save it in a VARIABLE called 'message'.
message = input("Type a message: ")

# Now let's see what the player wrote! Repeat the message back to the player.
print(message)
