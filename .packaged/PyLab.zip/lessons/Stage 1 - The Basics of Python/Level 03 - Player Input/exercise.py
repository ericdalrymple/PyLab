# ================================================================================================== #
# EXERCISE:
#
#   Try asking the player multiple different questions and saving their answers in different
#   VARIABLES. Then try to print the values the player wrote.
#
# ================================================================================================== #


