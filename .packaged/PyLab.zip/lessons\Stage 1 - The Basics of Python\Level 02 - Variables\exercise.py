# ================================================================================================== #
# EXERCISE:
#
#   Change the print instruction to use a VARIABLE. You can change the message if you like.
#
# ================================================================================================== #

# Change this print instruction to use a VARIABLE.
print("This text should be saved to a variable.")
