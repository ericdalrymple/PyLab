# ================================================================================================== #
# EXERCISE:
#
#   Here we ask the player to open one of three doors. You get to decide what is behind the door!
#
#   When the player chooses a door, use the 'if' instruction to tell them what they find!
#
# ================================================================================================== #

door = input("Which door do you want to open? (1, 2, or 3)")
door = int(door)

# Your code below this line.
