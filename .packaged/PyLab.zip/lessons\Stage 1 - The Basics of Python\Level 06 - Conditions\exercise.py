# ================================================================================================== #
# EXERCISE:
#
#   Ask the computer if 'a' is bigger or equal to 'b' and print the answer.
#   Ask the computer if 'a' is smaller or equal to 'b' and print the answer.
#
# ================================================================================================== #

a = input("Type a number: ")
b = input("Type amother number: ")

# Turn the player's answers into numbers
a = int(a)
b = int(b)

# Write your code below this line.
